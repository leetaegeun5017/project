# Android: Face Filters

[![github home](https://img.shields.io/badge/gaetanozappi-android--face--filters-blue.svg?style=flat)](https://github.com/gaetanozappi/android-face-filters)

[![github issues](https://img.shields.io/github/issues/gaetanozappi/Android-face-filters.svg?style=flat)](https://github.com/gaetanozappi/Android-face-filters/issues)
[![github closed issues](https://img.shields.io/github/issues-closed/gaetanozappi/Android-face-filters.svg?style=flat&colorB=44cc11)](https://github.com/gaetanozappi/Android-face-filters/issues?q=is%3Aissue+is%3Aclosed)
[![Issue Stats](https://img.shields.io/issuestats/i/github/gaetanozappi/Android-face-filters.svg?style=flat&colorB=44cc11)](http://github.com/gaetanozappi/Android-face-filters/issues)
[![github license](https://img.shields.io/github/license/gaetanozappi/Android-face-filters.svg)]()

![PNG](screenshot/android-face-filters.png)

-   [License](#-license)

Snapchat and Instagram like Face Filters.

It is based on the following project:

https://github.com/googlesamples/android-vision/tree/master/visionSamples/FaceTracker

## 📜 License
This library is provided under the Apache License.
